from django.shortcuts import render
from testapp.models import Post
from testapp.serialisers import SignUpSerializer,PostSerializer
from rest_framework import generics,views
from django.contrib.auth.models import User
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated

from rest_framework import response
# Create your views here.


class Post_info(generics.ListCreateAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    authentication_classes =[JWTAuthentication]
    permission_classes = [IsAuthenticated]


class Post_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Post.objects.all()
    serializer_class= PostSerializer
    authentication_classes =[JWTAuthentication]
    permission_classes = [IsAuthenticated]



class SignUpAPI(views.APIView):
    def post(self,request):
        serializer = SignUpSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return response.Response(data=serializer.data)
        return response.Response(data=serializer.errors)


