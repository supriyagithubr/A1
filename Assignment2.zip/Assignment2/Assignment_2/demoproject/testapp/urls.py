from django.urls import path
from . views import SignUpAPI,Post_details,Post_info

urlpatterns =[
    path('signup/',SignUpAPI.as_view()),
    path('detail/<int:pk>/', Post_details.as_view()),
    path('info/',Post_info.as_view())
]