from rest_framework import serializers,response
from testapp .models import Post
from django.contrib.auth.models import User


class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = '__all__'

class SignUpSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only = True)
    class Meta:
        model = User
        fields = ('username','password','email')


    def create(self,validated_data):
        return User.objects.create_user(** validated_data )

       
